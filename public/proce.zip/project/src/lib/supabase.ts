import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Lens = {
  id: string;
  brand: string;
  name: string;
  design: string | null;
  material: string | null;
  index: number | null;
  coating: string[];
  photochromic: boolean;
  photochromic_type: string | null;
  progressive: boolean;
  progressive_corridor: string | null;
  lens_type: string;
  sph_range: string | null;
  cyl_range: string | null;
  sph_max: number | null;
  cyl_max: number | null;
  diameter: number[];
  price: number;
  currency: string;
  notes: string | null;
  created_at: string;
  on_sale: boolean;
  sale_price: number | null;
  sale_note: string | null;
  sale_ends_at: string | null;
  sale_discount_type: 'percent' | 'amount' | null;
  sale_discount_value: number | null;
  purchase_price: number | null;
  delivery_days: number | null;
  delivery_note: string | null;
  is_available: boolean;
  manufacturer_id: string | null;
  product_line_id: string | null;
  coating_id: string | null;
  photochromic_id: string | null;
};

export type Manufacturer = {
  id: string;
  name: string;
  country: string | null;
  logo_url: string | null;
  description: string | null;
  created_at: string;
};

export type ProductLine = {
  id: string;
  manufacturer_id: string;
  name: string;
  lens_type: string | null;
  description: string | null;
  created_at: string;
};

export type Coating = {
  id: string;
  manufacturer_id: string;
  name: string;
  type: string | null;
  description: string | null;
  advantages: string[];
  light_transmission: number | null;
  residual_reflection_color: string | null;
  created_at: string;
};

export type Photochromic = {
  id: string;
  manufacturer_id: string;
  name: string;
  description: string | null;
  available_colors: string[];
  activation_time_sec: number | null;
  fading_time_sec: number | null;
  darkness_category: number | null;
  uv_protection: boolean;
  created_at: string;
};
