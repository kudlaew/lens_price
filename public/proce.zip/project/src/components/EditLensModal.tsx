import { useState } from 'react';
import { supabase, type Lens } from '@/lib/supabase';
import {
  X,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Save,
} from 'lucide-react';

export function EditLensModal({
  lens,
  onClose,
  onUpdated,
}: {
  lens: Lens;
  onClose: () => void;
  onUpdated: (updated: Lens) => void;
}) {
  const [form, setForm] = useState({
    brand: lens.brand,
    name: lens.name,
    design: lens.design ?? '',
    material: lens.material ?? '',
    index: lens.index != null ? String(lens.index) : '',
    coating: lens.coating.join(', '),
    photochromic: lens.photochromic,
    photochromic_type: lens.photochromic_type ?? '',
    progressive: lens.progressive,
    progressive_corridor: lens.progressive_corridor ?? '',
    lens_type: lens.lens_type,
    sph_range: lens.sph_range ?? '',
    cyl_range: lens.cyl_range ?? '',
    sph_max: lens.sph_max != null ? String(lens.sph_max) : '',
    cyl_max: lens.cyl_max != null ? String(lens.cyl_max) : '',
    diameter: lens.diameter.join(', '),
    price: String(lens.price),
    currency: lens.currency,
    notes: lens.notes ?? '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const set = (key: keyof typeof form, value: string | boolean) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = async () => {
    setSaving(true);
    setError(null);

    const updates: Partial<Lens> = {
      brand: form.brand.trim(),
      name: form.name.trim(),
      design: form.design.trim() || null,
      material: form.material.trim() || null,
      index: form.index.trim() === '' ? null : Number(form.index),
      coating: form.coating.split(',').map((s) => s.trim()).filter(Boolean),
      photochromic: form.photochromic,
      photochromic_type: form.photochromic ? (form.photochromic_type.trim() || null) : null,
      progressive: form.progressive,
      progressive_corridor: form.progressive ? (form.progressive_corridor.trim() || null) : null,
      lens_type: form.lens_type.trim(),
      sph_range: form.sph_range.trim() || null,
      cyl_range: form.cyl_range.trim() || null,
      sph_max: form.sph_max.trim() === '' ? null : Number(form.sph_max),
      cyl_max: form.cyl_max.trim() === '' ? null : Number(form.cyl_max),
      diameter: form.diameter.split(',').map((s) => Number(s.trim())).filter((n) => !isNaN(n)),
      price: Number(form.price),
      currency: form.currency.trim() || 'RUB',
      notes: form.notes.trim() || null,
    };

    if (!updates.brand || !updates.name) {
      setError('Бренд и название обязательны');
      setSaving(false);
      return;
    }
    if (isNaN(Number(updates.price))) {
      setError('Цена должна быть числом');
      setSaving(false);
      return;
    }

    const { data, error } = await supabase
      .from('lenses')
      .update(updates)
      .eq('id', lens.id)
      .select()
      .maybeSingle();

    if (error) {
      setError(error.message);
      setSaving(false);
    } else if (data) {
      setDone(true);
      setTimeout(() => onUpdated(data as Lens), 800);
    }
  };

  const inputClass = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 placeholder-slate-400 focus:border-blue-400 focus:outline-none focus:ring-2 focus:ring-blue-100';
  const labelClass = 'mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" />
      <div
        className="relative z-10 w-full max-w-2xl rounded-2xl bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-slate-100 p-6">
          <h2 className="text-lg font-bold text-slate-900">Редактирование линзы</h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[65vh] overflow-y-auto p-6">
          {done ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100">
                <CheckCircle2 className="h-7 w-7 text-emerald-600" />
              </div>
              <p className="text-base font-semibold text-slate-900">Сохранено</p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className={labelClass}>Бренд</label>
                  <input value={form.brand} onChange={(e) => set('brand', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Название</label>
                  <input value={form.name} onChange={(e) => set('name', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Тип линзы</label>
                  <input value={form.lens_type} onChange={(e) => set('lens_type', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Дизайн</label>
                  <input value={form.design} onChange={(e) => set('design', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Материал</label>
                  <input value={form.material} onChange={(e) => set('material', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Индекс</label>
                  <input value={form.index} onChange={(e) => set('index', e.target.value)} placeholder="1.67" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Цена</label>
                  <input type="number" value={form.price} onChange={(e) => set('price', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Валюта</label>
                  <input value={form.currency} onChange={(e) => set('currency', e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Диаметр (через запятую)</label>
                  <input value={form.diameter} onChange={(e) => set('diameter', e.target.value)} placeholder="65, 70, 75" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Покрытия (через запятую)</label>
                  <input value={form.coating} onChange={(e) => set('coating', e.target.value)} placeholder="Упрочнение, Антиблик" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Диапазон сферы</label>
                  <input value={form.sph_range} onChange={(e) => set('sph_range', e.target.value)} placeholder="+8.00 до -8.00" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Диапазон цилиндра</label>
                  <input value={form.cyl_range} onChange={(e) => set('cyl_range', e.target.value)} placeholder="до -4.00" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Макс. сфера</label>
                  <input type="number" step="0.25" value={form.sph_max} onChange={(e) => set('sph_max', e.target.value)} placeholder="8.00" className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Макс. цилиндр</label>
                  <input type="number" step="0.25" value={form.cyl_max} onChange={(e) => set('cyl_max', e.target.value)} placeholder="4.00" className={inputClass} />
                </div>
              </div>

              <div className="flex gap-6">
                <label className="flex items-center gap-2 text-sm text-slate-700">
                  <input type="checkbox" checked={form.photochromic} onChange={(e) => set('photochromic', e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-200" />
                  Фотохром
                </label>
                {form.photochromic && (
                  <input value={form.photochromic_type} onChange={(e) => set('photochromic_type', e.target.value)} placeholder="Тип фотохрома" className={`flex-1 ${inputClass}`} />
                )}
              </div>

              <div className="flex gap-6">
                <label className="flex items-center gap-2 text-sm text-slate-700">
                  <input type="checkbox" checked={form.progressive} onChange={(e) => set('progressive', e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-200" />
                  Прогрессивная
                </label>
                {form.progressive && (
                  <input value={form.progressive_corridor} onChange={(e) => set('progressive_corridor', e.target.value)} placeholder="Коридор прогрессии" className={`flex-1 ${inputClass}`} />
                )}
              </div>

              <div>
                <label className={labelClass}>Примечания</label>
                <textarea value={form.notes} onChange={(e) => set('notes', e.target.value)} rows={2} className={`resize-none ${inputClass}`} />
              </div>

              {error && (
                <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                  <AlertCircle className="h-4 w-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  onClick={handleSubmit}
                  disabled={saving}
                  className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-50"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  Сохранить
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
